class AppRoutes{
  //welcomepage or on boarding
  static const INITIAL="/";
  //bottombar screen
  static  const APPLICATION="/application";
  static const SIGNIN="/sign_in";
  static const SIGNUP="/sign_up";
}