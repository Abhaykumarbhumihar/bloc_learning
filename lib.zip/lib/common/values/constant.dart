class AppConstant{
  static const String INTRO_COMPLETE="intro_complete";
}