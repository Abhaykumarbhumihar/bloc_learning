class WelcomeState{
  int page;
  WelcomeState({this.page=0});


}