import 'package:bloc_learning/pages/product/domain/entities/product.dart';
import 'package:bloc_learning/pages/product/domain/repositery/product_repositery.dart';

class ProductRepositeryImpl extends ProductRepositery{


  @override
  Future<Product?> getProduct() {

    throw UnimplementedError();
  }

}